import SwiftUI
import AVFoundation
import Vision
import UIKit

struct PoseCameraView: UIViewRepresentable {
    let exerciseKind: ExerciseKind
    @Binding var feedback: String

    func makeUIView(context: Context) -> PosePreviewView {
        let view = PosePreviewView()
        context.coordinator.previewView = view
        context.coordinator.startSession()
        return view
    }

    func updateUIView(_ uiView: PosePreviewView, context: Context) {}

    static func dismantleUIView(_ uiView: PosePreviewView, coordinator: Coordinator) {
        coordinator.stopSession()
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(exerciseKind: exerciseKind, feedback: $feedback)
    }

    final class Coordinator: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
        private let session = AVCaptureSession()
        private let videoQueue = DispatchQueue(label: "gymmate.pose.video.queue")
        private var isProcessingFrame = false
        private let exerciseKind: ExerciseKind
        private var feedback: Binding<String>
        weak var previewView: PosePreviewView?

        init(exerciseKind: ExerciseKind, feedback: Binding<String>) {
            self.exerciseKind = exerciseKind
            self.feedback = feedback
            super.init()
        }

        func startSession() {
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self else { return }
                if granted {
                    self.configureSession()
                } else {
                    DispatchQueue.main.async {
                        self.feedback.wrappedValue = "Bạn chưa cấp quyền camera"
                    }
                }
            }
        }

        func stopSession() {
            videoQueue.async { [weak self] in
                self?.session.stopRunning()
            }
        }

        private func configureSession() {
            videoQueue.async { [weak self] in
                guard let self else { return }

                self.session.beginConfiguration()
                self.session.sessionPreset = .high

                guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
                      let input = try? AVCaptureDeviceInput(device: camera),
                      self.session.canAddInput(input) else {
                    DispatchQueue.main.async {
                        self.feedback.wrappedValue = "Không mở được camera trước"
                    }
                    self.session.commitConfiguration()
                    return
                }

                self.session.addInput(input)

                let output = AVCaptureVideoDataOutput()
                output.alwaysDiscardsLateVideoFrames = true
                output.videoSettings = [
                    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
                ]
                output.setSampleBufferDelegate(self, queue: self.videoQueue)

                guard self.session.canAddOutput(output) else {
                    DispatchQueue.main.async {
                        self.feedback.wrappedValue = "Không tạo được camera output"
                    }
                    self.session.commitConfiguration()
                    return
                }

                self.session.addOutput(output)

                if let connection = output.connection(with: .video) {
                    if connection.isVideoOrientationSupported {
                        connection.videoOrientation = .portrait
                    }
                    if connection.isVideoMirroringSupported {
                        connection.isVideoMirrored = true
                    }
                }

                self.session.commitConfiguration()

                DispatchQueue.main.async {
                    self.previewView?.previewLayer.session = self.session
                    self.previewView?.previewLayer.videoGravity = .resizeAspectFill
                }

                self.session.startRunning()
            }
        }

        func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
            guard !isProcessingFrame else { return }
            isProcessingFrame = true
            defer { isProcessingFrame = false }

            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

            let request = VNDetectHumanBodyPoseRequest()
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .leftMirrored, options: [:])

            do {
                try handler.perform([request])
                guard let observation = request.results?.first else {
                    DispatchQueue.main.async {
                        self.previewView?.clearSkeleton()
                        self.feedback.wrappedValue = "Không thấy người. Hãy đứng xa camera hơn"
                    }
                    return
                }

                let recognizedPoints = try observation.recognizedPoints(.all)
                let message = self.makeFeedback(from: recognizedPoints)

                DispatchQueue.main.async {
                    self.previewView?.drawSkeleton(points: recognizedPoints)
                    self.feedback.wrappedValue = message
                }
            } catch {
                DispatchQueue.main.async {
                    self.feedback.wrappedValue = "Lỗi nhận dáng người: \(error.localizedDescription)"
                }
            }
        }

        private func makeFeedback(from points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint]) -> String {
            switch exerciseKind {
            case .squat:
                return squatFeedback(points)
            case .pushup:
                return pushupFeedback(points)
            case .plank:
                return plankFeedback(points)
            case .lunge:
                return lungeFeedback(points)
            default:
                return "Giữ toàn thân trong khung hình để app vẽ hình que"
            }
        }

        private func squatFeedback(_ points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint]) -> String {
            guard let hip = bestPoint(points, .leftHip, .rightHip),
                  let knee = bestPoint(points, .leftKnee, .rightKnee),
                  let ankle = bestPoint(points, .leftAnkle, .rightAnkle),
                  let shoulder = bestPoint(points, .leftShoulder, .rightShoulder) else {
                return "Squat: cần thấy vai, hông, gối và cổ chân"
            }

            let kneeAngle = angle(a: hip, b: knee, c: ankle)
            let backAngle = angle(a: shoulder, b: hip, c: knee)

            if backAngle < 95 {
                return "Squat: lưng đang gập nhiều, cố giữ ngực mở hơn"
            }

            if kneeAngle > 155 {
                return "Squat: hãy hạ người xuống thêm"
            }

            if kneeAngle < 65 {
                return "Squat: xuống hơi sâu, giữ kiểm soát đầu gối"
            }

            return "Squat ổn: giữ lưng thẳng và đẩy gối theo mũi chân"
        }

        private func pushupFeedback(_ points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint]) -> String {
            guard let shoulder = bestPoint(points, .leftShoulder, .rightShoulder),
                  let elbow = bestPoint(points, .leftElbow, .rightElbow),
                  let wrist = bestPoint(points, .leftWrist, .rightWrist),
                  let hip = bestPoint(points, .leftHip, .rightHip),
                  let ankle = bestPoint(points, .leftAnkle, .rightAnkle) else {
                return "Push-up: cần thấy vai, tay, hông và chân"
            }

            let elbowAngle = angle(a: shoulder, b: elbow, c: wrist)
            let bodyAngle = angle(a: shoulder, b: hip, c: ankle)

            if bodyAngle < 155 {
                return "Push-up: giữ vai, hông và chân thẳng hơn"
            }

            if elbowAngle > 155 {
                return "Push-up: hạ thấp người xuống thêm"
            }

            if elbowAngle < 70 {
                return "Push-up: xuống hơi sâu, kiểm soát vai"
            }

            return "Push-up ổn: thân người thẳng, tiếp tục giữ nhịp"
        }

        private func plankFeedback(_ points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint]) -> String {
            guard let shoulder = bestPoint(points, .leftShoulder, .rightShoulder),
                  let hip = bestPoint(points, .leftHip, .rightHip),
                  let ankle = bestPoint(points, .leftAnkle, .rightAnkle) else {
                return "Plank: cần thấy vai, hông và chân"
            }

            let bodyAngle = angle(a: shoulder, b: hip, c: ankle)

            if bodyAngle < 155 {
                return "Plank: hông đang võng hoặc nâng cao, chỉnh thân người thẳng"
            }

            return "Plank ổn: giữ bụng căng và thở đều"
        }

        private func lungeFeedback(_ points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint]) -> String {
            guard let hip = bestPoint(points, .leftHip, .rightHip),
                  let knee = bestPoint(points, .leftKnee, .rightKnee),
                  let ankle = bestPoint(points, .leftAnkle, .rightAnkle),
                  let shoulder = bestPoint(points, .leftShoulder, .rightShoulder) else {
                return "Lunge: cần thấy vai, hông, gối và cổ chân"
            }

            let kneeAngle = angle(a: hip, b: knee, c: ankle)
            let torsoAngle = angle(a: shoulder, b: hip, c: knee)

            if torsoAngle < 95 {
                return "Lunge: người đang đổ về trước, giữ thân trên thẳng hơn"
            }

            if kneeAngle > 155 {
                return "Lunge: hãy hạ gối xuống thêm"
            }

            return "Lunge ổn: giữ gối ổn định và thân người thẳng"
        }

        private func bestPoint(_ points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint], _ first: VNHumanBodyPoseObservation.JointName, _ second: VNHumanBodyPoseObservation.JointName) -> CGPoint? {
            let p1 = points[first]
            let p2 = points[second]

            if let p1, p1.confidence > 0.25, let p2, p2.confidence > 0.25 {
                return CGPoint(x: (p1.location.x + p2.location.x) / 2, y: (p1.location.y + p2.location.y) / 2)
            }

            if let p1, p1.confidence > 0.25 {
                return p1.location
            }

            if let p2, p2.confidence > 0.25 {
                return p2.location
            }

            return nil
        }

        private func angle(a: CGPoint, b: CGPoint, c: CGPoint) -> Double {
            let ab = CGVector(dx: a.x - b.x, dy: a.y - b.y)
            let cb = CGVector(dx: c.x - b.x, dy: c.y - b.y)

            let dot = ab.dx * cb.dx + ab.dy * cb.dy
            let magAB = sqrt(ab.dx * ab.dx + ab.dy * ab.dy)
            let magCB = sqrt(cb.dx * cb.dx + cb.dy * cb.dy)

            guard magAB > 0, magCB > 0 else { return 0 }

            let cosine = max(-1, min(1, dot / (magAB * magCB)))
            return acos(cosine) * 180 / .pi
        }
    }
}

final class PosePreviewView: UIView {
    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }

    var previewLayer: AVCaptureVideoPreviewLayer {
        layer as! AVCaptureVideoPreviewLayer
    }

    private let skeletonLayer = CAShapeLayer()
    private let jointLayer = CAShapeLayer()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayers()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupLayers()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        skeletonLayer.frame = bounds
        jointLayer.frame = bounds
    }

    private func setupLayers() {
        previewLayer.videoGravity = .resizeAspectFill

        skeletonLayer.strokeColor = UIColor.systemGreen.cgColor
        skeletonLayer.lineWidth = 5
        skeletonLayer.lineCap = .round
        skeletonLayer.fillColor = UIColor.clear.cgColor

        jointLayer.fillColor = UIColor.systemYellow.cgColor
        jointLayer.strokeColor = UIColor.black.cgColor
        jointLayer.lineWidth = 1

        layer.addSublayer(skeletonLayer)
        layer.addSublayer(jointLayer)
    }

    func clearSkeleton() {
        skeletonLayer.path = nil
        jointLayer.path = nil
    }

    func drawSkeleton(points: [VNHumanBodyPoseObservation.JointName: VNRecognizedPoint]) {
        let skeletonPath = UIBezierPath()
        let jointPath = UIBezierPath()

        let pairs: [(VNHumanBodyPoseObservation.JointName, VNHumanBodyPoseObservation.JointName)] = [
            (.neck, .leftShoulder), (.neck, .rightShoulder),
            (.leftShoulder, .leftElbow), (.leftElbow, .leftWrist),
            (.rightShoulder, .rightElbow), (.rightElbow, .rightWrist),
            (.neck, .root),
            (.root, .leftHip), (.root, .rightHip),
            (.leftHip, .leftKnee), (.leftKnee, .leftAnkle),
            (.rightHip, .rightKnee), (.rightKnee, .rightAnkle)
        ]

        func convertedPoint(_ joint: VNHumanBodyPoseObservation.JointName) -> CGPoint? {
            guard let point = points[joint], point.confidence > 0.25 else { return nil }
            let capturePoint = CGPoint(x: point.location.x, y: 1 - point.location.y)
            return previewLayer.layerPointConverted(fromCaptureDevicePoint: capturePoint)
        }

        for (start, end) in pairs {
            guard let p1 = convertedPoint(start), let p2 = convertedPoint(end) else { continue }
            skeletonPath.move(to: p1)
            skeletonPath.addLine(to: p2)
        }

        for joint in points.keys {
            guard let p = convertedPoint(joint) else { continue }
            jointPath.move(to: CGPoint(x: p.x + 6, y: p.y))
            jointPath.addArc(withCenter: p, radius: 6, startAngle: 0, endAngle: .pi * 2, clockwise: true)
        }

        skeletonLayer.path = skeletonPath.cgPath
        jointLayer.path = jointPath.cgPath
    }
}
