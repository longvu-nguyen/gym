import SwiftUI

struct HistoryView: View {
    @EnvironmentObject private var store: WorkoutStore

    var body: some View {
        NavigationStack {
            List {
                if store.sessions.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "calendar.badge.clock")
                            .font(.system(size: 44))
                            .foregroundStyle(.secondary)
                        Text("Chưa có lịch sử")
                            .font(.headline)
                        Text("Tập xong và bấm lưu thì buổi tập sẽ hiện ở đây.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
                } else {
                    ForEach(store.sessions) { session in
                        NavigationLink {
                            SessionDetailView(session: session)
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(session.title)
                                    .font(.headline)
                                Text(session.place.rawValue)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                Text(session.date.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .onDelete(perform: store.deleteSessions)
                }
            }
            .navigationTitle("Lịch sử tập")
        }
    }
}

struct SessionDetailView: View {
    let session: WorkoutSession

    var body: some View {
        List {
            Section("Thông tin") {
                LabeledContent("Ngày", value: session.date.formatted(date: .complete, time: .shortened))
                LabeledContent("Kiểu tập", value: session.place.rawValue)
                if !session.note.isEmpty {
                    Text(session.note)
                }
            }

            Section("Bài đã tập") {
                ForEach(session.exercises) { log in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(log.exercise.name)
                            .font(.headline)
                        Text("\(log.completedSets)/\(log.exercise.sets) hiệp • \(log.exercise.repsText)")
                            .foregroundStyle(.secondary)
                        if !log.weightText.isEmpty {
                            Text("Tạ: \(log.weightText)")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle(session.title)
    }
}
