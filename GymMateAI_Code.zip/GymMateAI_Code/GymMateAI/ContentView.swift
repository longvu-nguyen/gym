import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Hôm nay", systemImage: "figure.strengthtraining.traditional")
                }

            HistoryView()
                .tabItem {
                    Label("Lịch sử", systemImage: "calendar")
                }

            SettingsView()
                .tabItem {
                    Label("Cài đặt", systemImage: "gearshape")
                }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var store: WorkoutStore

    var plan: DailyWorkoutPlan {
        store.todayPlan()
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    headerCard
                    placePicker
                    exerciseList

                    NavigationLink {
                        WorkoutRunView(plan: plan, logs: store.makeLogsForToday())
                    } label: {
                        Text("Bắt đầu tập")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.accentColor)
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                }
                .padding()
            }
            .navigationTitle("GymMate AI")
        }
    }

    private var headerCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Hôm nay")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Text(plan.title)
                .font(.largeTitle.bold())

            Text(plan.place.rawValue)
                .font(.headline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private var placePicker: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Chọn kiểu tập")
                .font(.headline)

            Picker("Kiểu tập", selection: $store.selectedPlace) {
                ForEach(WorkoutPlace.allCases) { place in
                    Text(place.rawValue).tag(place)
                }
            }
            .pickerStyle(.segmented)
        }
    }

    private var exerciseList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Bài tập hôm nay")
                .font(.headline)

            ForEach(plan.exercises) { exercise in
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(exercise.name)
                            .font(.headline)
                        Text("\(exercise.sets) hiệp • \(exercise.repsText) • nghỉ \(exercise.restSeconds)s")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    if exercise.canUseCamera {
                        Image(systemName: "camera.viewfinder")
                            .foregroundStyle(.blue)
                    }
                }
                .padding()
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }
        }
    }
}
