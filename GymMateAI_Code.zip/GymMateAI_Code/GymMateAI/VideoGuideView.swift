import SwiftUI
import AVKit

struct VideoGuideView: View {
    let exercise: Exercise

    var body: some View {
        if let videoName = exercise.videoName,
           let url = Bundle.main.url(forResource: videoName, withExtension: "mp4") {
            VideoPlayer(player: AVPlayer(url: url))
        } else {
            VStack(spacing: 12) {
                Image(systemName: "play.rectangle.fill")
                    .font(.system(size: 52))
                    .foregroundStyle(.secondary)

                Text("Video hướng dẫn: \(exercise.name)")
                    .font(.headline)

                Text("Muốn có video thật thì kéo file \(exercise.videoName ?? "video").mp4 vào Xcode. Không có video thì app vẫn chạy.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(.secondarySystemBackground))
        }
    }
}
