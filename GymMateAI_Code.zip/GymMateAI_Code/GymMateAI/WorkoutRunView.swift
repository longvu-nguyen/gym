import SwiftUI

struct WorkoutRunView: View {
    @EnvironmentObject private var store: WorkoutStore
    @Environment(\.dismiss) private var dismiss

    let plan: DailyWorkoutPlan
    @State var logs: [ExerciseLog]

    @State private var currentIndex = 0
    @State private var restRemaining = 0
    @State private var isResting = false
    @State private var note = ""
    @State private var showFinishedAlert = false

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack(spacing: 0) {
            progressHeader

            if logs.indices.contains(currentIndex) {
                ScrollView {
                    VStack(spacing: 16) {
                        VideoGuideView(exercise: logs[currentIndex].exercise)
                            .frame(height: 220)
                            .clipShape(RoundedRectangle(cornerRadius: 18))

                        currentExerciseCard

                        if isResting {
                            restCard
                        }

                        TextField("Ghi chú buổi tập", text: $note, axis: .vertical)
                            .textFieldStyle(.roundedBorder)
                    }
                    .padding()
                }
            } else {
                finishView
            }
        }
        .navigationTitle(plan.title)
        .navigationBarTitleDisplayMode(.inline)
        .onReceive(timer) { _ in
            guard isResting else { return }
            if restRemaining > 0 {
                restRemaining -= 1
            } else {
                isResting = false
            }
        }
        .alert("Đã lưu buổi tập", isPresented: $showFinishedAlert) {
            Button("OK") { dismiss() }
        } message: {
            Text("Lịch sử hôm nay đã được lưu lại.")
        }
    }

    private var progressHeader: some View {
        VStack(alignment: .leading, spacing: 8) {
            let done = logs.filter { $0.isDone }.count
            Text("Tiến độ: \(done)/\(logs.count) bài")
                .font(.headline)

            ProgressView(value: Double(done), total: Double(max(logs.count, 1)))
        }
        .padding()
        .background(Color(.systemBackground))
    }

    private var currentExerciseCard: some View {
        let log = logs[currentIndex]
        let exercise = log.exercise

        return VStack(alignment: .leading, spacing: 14) {
            Text(exercise.name)
                .font(.largeTitle.bold())

            Text("\(exercise.sets) hiệp • \(exercise.repsText)")
                .font(.headline)
                .foregroundStyle(.secondary)

            HStack {
                Text("Đã xong: \(log.completedSets)/\(exercise.sets) hiệp")
                    .font(.headline)
                Spacer()
            }

            if exercise.canUseCamera {
                NavigationLink {
                    PoseCoachView(exerciseKind: exercise.kind, exerciseName: exercise.name)
                } label: {
                    Label("Bật camera hình que", systemImage: "camera.viewfinder")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            }

            TextField("Tạ dùng hôm nay, ví dụ 10kg hoặc không tạ", text: bindingForWeight(index: currentIndex))
                .textFieldStyle(.roundedBorder)

            Button {
                finishOneSet()
            } label: {
                Text(buttonTitle)
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .disabled(isResting)
        }
        .padding()
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private var restCard: some View {
        VStack(spacing: 12) {
            Text("Nghỉ giữa hiệp")
                .font(.headline)

            Text(timeString(restRemaining))
                .font(.system(size: 54, weight: .bold, design: .rounded))

            HStack {
                Button("Bỏ qua") {
                    isResting = false
                    restRemaining = 0
                }
                .buttonStyle(.borderedProminent)

                Button("+30 giây") {
                    restRemaining += 30
                }
                .buttonStyle(.bordered)
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.orange.opacity(0.15))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private var finishView: some View {
        VStack(spacing: 20) {
            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 70))
                .foregroundStyle(.green)

            Text("Hoàn thành buổi tập")
                .font(.largeTitle.bold())

            Button("Lưu vào lịch sử") {
                store.saveWorkout(title: plan.title, place: plan.place, logs: logs, note: note)
                showFinishedAlert = true
            }
            .font(.headline)
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }

    private var buttonTitle: String {
        guard logs.indices.contains(currentIndex) else { return "Xong" }
        let log = logs[currentIndex]
        if log.completedSets + 1 >= log.exercise.sets {
            return "Xong bài này"
        }
        return "Xong hiệp \(log.completedSets + 1)"
    }

    private func bindingForWeight(index: Int) -> Binding<String> {
        Binding(
            get: { logs[index].weightText },
            set: { logs[index].weightText = $0 }
        )
    }

    private func finishOneSet() {
        guard logs.indices.contains(currentIndex) else { return }

        logs[currentIndex].completedSets += 1
        let exercise = logs[currentIndex].exercise

        if logs[currentIndex].completedSets < exercise.sets {
            restRemaining = exercise.restSeconds
            isResting = true
        } else {
            isResting = false
            restRemaining = 0
            currentIndex += 1
        }
    }

    private func timeString(_ seconds: Int) -> String {
        let min = seconds / 60
        let sec = seconds % 60
        return String(format: "%02d:%02d", min, sec)
    }
}
