import SwiftUI

struct PoseCoachView: View {
    let exerciseKind: ExerciseKind
    let exerciseName: String

    @State private var feedback = "Đưa toàn thân vào khung hình"

    var body: some View {
        ZStack(alignment: .bottom) {
            PoseCameraView(exerciseKind: exerciseKind, feedback: $feedback)
                .ignoresSafeArea(edges: .bottom)

            VStack(spacing: 10) {
                Text(exerciseName)
                    .font(.headline)
                    .foregroundStyle(.white)

                Text(feedback)
                    .font(.title3.bold())
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.black.opacity(0.65))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            .padding()
        }
        .navigationTitle("Camera hình que")
        .navigationBarTitleDisplayMode(.inline)
    }
}
