import Foundation

struct WorkoutLibrary {
    static func plan(for place: WorkoutPlace, date: Date = Date()) -> DailyWorkoutPlan {
        let weekday = Calendar.current.component(.weekday, from: date)

        switch place {
        case .gym:
            return gymPlan(weekday: weekday)
        case .homeDumbbell:
            return homeDumbbellPlan(weekday: weekday)
        case .homeNoEquipment:
            return homeNoEquipmentPlan(weekday: weekday)
        }
    }

    private static func e(_ name: String, _ sets: Int, _ reps: String, _ rest: Int, _ kind: ExerciseKind, _ video: String? = nil) -> Exercise {
        Exercise(name: name, sets: sets, repsText: reps, restSeconds: rest, videoName: video, kind: kind)
    }

    private static func gymPlan(weekday: Int) -> DailyWorkoutPlan {
        switch weekday {
        case 2:
            return DailyWorkoutPlan(title: "Ngực + tay sau", place: .gym, exercises: [
                e("Bench Press", 4, "8-10 lần", 90, .benchPress, "benchpress"),
                e("Dumbbell Press", 3, "10-12 lần", 75, .other, "dumbbellpress"),
                e("Triceps Pushdown", 3, "12 lần", 60, .tricepsPushdown, "tricepspushdown"),
                e("Plank", 3, "30-45 giây", 45, .plank, "plank")
            ])
        case 3:
            return DailyWorkoutPlan(title: "Lưng + tay trước", place: .gym, exercises: [
                e("Lat Pulldown", 4, "10-12 lần", 75, .latPulldown, "latpulldown"),
                e("Cable Row", 3, "10-12 lần", 75, .cableRow, "cablerow"),
                e("Dumbbell Curl", 3, "12 lần", 60, .dumbbellCurl, "curl"),
                e("Crunch", 3, "15 lần", 45, .crunch, "crunch")
            ])
        case 4:
            return DailyWorkoutPlan(title: "Chân", place: .gym, exercises: [
                e("Squat", 4, "8-12 lần", 90, .squat, "squat"),
                e("Leg Press", 3, "10-12 lần", 90, .legPress, "legpress"),
                e("Lunge", 3, "10 lần mỗi chân", 60, .lunge, "lunge"),
                e("Plank", 3, "45 giây", 45, .plank, "plank")
            ])
        case 5:
            return DailyWorkoutPlan(title: "Vai + bụng", place: .gym, exercises: [
                e("Shoulder Press", 4, "8-12 lần", 75, .shoulderPress, "shoulderpress"),
                e("Lateral Raise", 3, "12-15 lần", 60, .other, "lateralraise"),
                e("Crunch", 3, "15-20 lần", 45, .crunch, "crunch"),
                e("Plank", 3, "45 giây", 45, .plank, "plank")
            ])
        case 6:
            return DailyWorkoutPlan(title: "Full body nhẹ", place: .gym, exercises: [
                e("Squat", 3, "10 lần", 75, .squat, "squat"),
                e("Push-up", 3, "8-12 lần", 60, .pushup, "pushup"),
                e("Dumbbell Row", 3, "12 lần", 60, .dumbbellRow, "dumbbellrow"),
                e("Shoulder Press", 3, "10 lần", 60, .shoulderPress, "shoulderpress")
            ])
        case 7:
            return DailyWorkoutPlan(title: "Cardio + bụng", place: .gym, exercises: [
                e("Jumping Jack", 3, "45 giây", 45, .jumpingJack, "jumpingjack"),
                e("Lunge", 3, "10 lần mỗi chân", 60, .lunge, "lunge"),
                e("Crunch", 3, "20 lần", 45, .crunch, "crunch"),
                e("Plank", 3, "45 giây", 45, .plank, "plank")
            ])
        default:
            return DailyWorkoutPlan(title: "Nghỉ / giãn cơ", place: .gym, exercises: [
                e("Plank nhẹ", 2, "30 giây", 45, .plank, "plank"),
                e("Squat không tạ", 2, "12 lần", 45, .squat, "squat")
            ])
        }
    }

    private static func homeDumbbellPlan(weekday: Int) -> DailyWorkoutPlan {
        switch weekday {
        case 2, 5:
            return DailyWorkoutPlan(title: "Thân trên với tạ", place: .homeDumbbell, exercises: [
                e("Push-up", 3, "8-12 lần", 60, .pushup, "pushup"),
                e("Dumbbell Row", 3, "12 lần", 60, .dumbbellRow, "dumbbellrow"),
                e("Shoulder Press", 3, "10-12 lần", 60, .shoulderPress, "shoulderpress"),
                e("Dumbbell Curl", 3, "12 lần", 45, .dumbbellCurl, "curl")
            ])
        case 3, 6:
            return DailyWorkoutPlan(title: "Chân + bụng với tạ", place: .homeDumbbell, exercises: [
                e("Goblet Squat", 4, "10-12 lần", 75, .squat, "squat"),
                e("Lunge", 3, "10 lần mỗi chân", 60, .lunge, "lunge"),
                e("Crunch", 3, "15-20 lần", 45, .crunch, "crunch"),
                e("Plank", 3, "45 giây", 45, .plank, "plank")
            ])
        case 4, 7:
            return DailyWorkoutPlan(title: "Full body với tạ", place: .homeDumbbell, exercises: [
                e("Squat", 3, "12 lần", 60, .squat, "squat"),
                e("Push-up", 3, "10 lần", 60, .pushup, "pushup"),
                e("Dumbbell Row", 3, "12 lần", 60, .dumbbellRow, "dumbbellrow"),
                e("Plank", 3, "45 giây", 45, .plank, "plank")
            ])
        default:
            return DailyWorkoutPlan(title: "Nghỉ / vận động nhẹ", place: .homeDumbbell, exercises: [
                e("Plank", 2, "30 giây", 45, .plank, "plank"),
                e("Squat nhẹ", 2, "12 lần", 45, .squat, "squat")
            ])
        }
    }

    private static func homeNoEquipmentPlan(weekday: Int) -> DailyWorkoutPlan {
        switch weekday {
        case 2, 4, 6:
            return DailyWorkoutPlan(title: "Full body tại nhà", place: .homeNoEquipment, exercises: [
                e("Squat", 3, "12 lần", 60, .squat, "squat"),
                e("Push-up", 3, "8-12 lần", 60, .pushup, "pushup"),
                e("Lunge", 3, "10 lần mỗi chân", 60, .lunge, "lunge"),
                e("Plank", 3, "30-45 giây", 45, .plank, "plank"),
                e("Crunch", 3, "15 lần", 45, .crunch, "crunch")
            ])
        case 3, 5:
            return DailyWorkoutPlan(title: "Cardio nhẹ tại nhà", place: .homeNoEquipment, exercises: [
                e("Jumping Jack", 3, "45 giây", 45, .jumpingJack, "jumpingjack"),
                e("Squat", 3, "12 lần", 60, .squat, "squat"),
                e("Mountain Climber", 3, "30 giây", 45, .other, "mountainclimber"),
                e("Plank", 3, "45 giây", 45, .plank, "plank")
            ])
        default:
            return DailyWorkoutPlan(title: "Nghỉ / giãn cơ", place: .homeNoEquipment, exercises: [
                e("Plank nhẹ", 2, "30 giây", 45, .plank, "plank"),
                e("Squat nhẹ", 2, "12 lần", 45, .squat, "squat")
            ])
        }
    }
}
