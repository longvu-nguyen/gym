import Foundation
import SwiftUI

final class WorkoutStore: ObservableObject {
    @Published var selectedPlace: WorkoutPlace = .homeNoEquipment {
        didSet { saveSettings() }
    }

    @Published var sessions: [WorkoutSession] = [] {
        didSet { saveSessions() }
    }

    @Published var reminderHour: Int = 18 {
        didSet { saveSettings() }
    }

    @Published var reminderMinute: Int = 30 {
        didSet { saveSettings() }
    }

    private let sessionsKey = "gymmate.sessions"
    private let placeKey = "gymmate.place"
    private let hourKey = "gymmate.reminder.hour"
    private let minuteKey = "gymmate.reminder.minute"

    init() {
        loadSettings()
        loadSessions()
    }

    func todayPlan() -> DailyWorkoutPlan {
        WorkoutLibrary.plan(for: selectedPlace)
    }

    func makeLogsForToday() -> [ExerciseLog] {
        todayPlan().exercises.map { ExerciseLog(exercise: $0) }
    }

    func saveWorkout(title: String, place: WorkoutPlace, logs: [ExerciseLog], note: String) {
        let session = WorkoutSession(
            date: Date(),
            title: title,
            place: place,
            exercises: logs,
            note: note
        )
        sessions.insert(session, at: 0)
    }

    func deleteSessions(at offsets: IndexSet) {
        sessions.remove(atOffsets: offsets)
    }

    private func saveSettings() {
        UserDefaults.standard.set(selectedPlace.rawValue, forKey: placeKey)
        UserDefaults.standard.set(reminderHour, forKey: hourKey)
        UserDefaults.standard.set(reminderMinute, forKey: minuteKey)
    }

    private func loadSettings() {
        if let rawPlace = UserDefaults.standard.string(forKey: placeKey),
           let place = WorkoutPlace(rawValue: rawPlace) {
            selectedPlace = place
        }

        let hour = UserDefaults.standard.integer(forKey: hourKey)
        let minute = UserDefaults.standard.integer(forKey: minuteKey)

        if hour >= 0 && hour <= 23 {
            reminderHour = hour
        }

        if minute >= 0 && minute <= 59 {
            reminderMinute = minute
        }
    }

    private func saveSessions() {
        do {
            let data = try JSONEncoder().encode(sessions)
            UserDefaults.standard.set(data, forKey: sessionsKey)
        } catch {
            print("Save sessions error:", error.localizedDescription)
        }
    }

    private func loadSessions() {
        guard let data = UserDefaults.standard.data(forKey: sessionsKey) else { return }
        do {
            sessions = try JSONDecoder().decode([WorkoutSession].self, from: data)
        } catch {
            print("Load sessions error:", error.localizedDescription)
        }
    }
}
