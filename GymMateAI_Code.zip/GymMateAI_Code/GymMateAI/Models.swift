import Foundation

enum WorkoutPlace: String, Codable, CaseIterable, Identifiable {
    case gym = "Phòng gym"
    case homeDumbbell = "Ở nhà có tạ"
    case homeNoEquipment = "Ở nhà không dụng cụ"

    var id: String { rawValue }
}

enum ExerciseKind: String, Codable, CaseIterable {
    case squat
    case pushup
    case plank
    case lunge
    case jumpingJack
    case crunch
    case dumbbellCurl
    case shoulderPress
    case benchPress
    case latPulldown
    case legPress
    case cableRow
    case dumbbellRow
    case tricepsPushdown
    case other
}

struct Exercise: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var sets: Int
    var repsText: String
    var restSeconds: Int
    var videoName: String?
    var kind: ExerciseKind

    var canUseCamera: Bool {
        [.squat, .pushup, .plank, .lunge].contains(kind)
    }
}

struct DailyWorkoutPlan: Identifiable, Codable {
    var id = UUID()
    var title: String
    var place: WorkoutPlace
    var exercises: [Exercise]
}

struct ExerciseLog: Identifiable, Codable, Hashable {
    var id = UUID()
    var exercise: Exercise
    var completedSets: Int = 0
    var weightText: String = ""

    var isDone: Bool {
        completedSets >= exercise.sets
    }
}

struct WorkoutSession: Identifiable, Codable {
    var id = UUID()
    var date: Date
    var title: String
    var place: WorkoutPlace
    var exercises: [ExerciseLog]
    var note: String
}
