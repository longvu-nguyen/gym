import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: WorkoutStore
    @State private var reminderDate = Date()
    @State private var message = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Báo thức tập") {
                    DatePicker("Giờ nhắc tập", selection: $reminderDate, displayedComponents: .hourAndMinute)

                    Button("Lưu báo thức mỗi ngày") {
                        let comps = Calendar.current.dateComponents([.hour, .minute], from: reminderDate)
                        store.reminderHour = comps.hour ?? 18
                        store.reminderMinute = comps.minute ?? 30
                        NotificationManager.shared.requestPermission()
                        NotificationManager.shared.scheduleDailyWorkoutReminder(
                            hour: store.reminderHour,
                            minute: store.reminderMinute
                        )
                        message = "Đã đặt báo thức lúc \(String(format: "%02d:%02d", store.reminderHour, store.reminderMinute)) mỗi ngày."
                    }

                    if !message.isEmpty {
                        Text(message)
                            .foregroundStyle(.green)
                    }
                }

                Section("Lưu ý camera") {
                    Text("Camera hình que dùng Vision để nhận các điểm cơ thể. Hãy đặt iPhone xa đủ để thấy toàn thân, ánh sáng rõ, mặc đồ không quá tối.")
                }
            }
            .navigationTitle("Cài đặt")
            .onAppear {
                var comps = Calendar.current.dateComponents([.year, .month, .day], from: Date())
                comps.hour = store.reminderHour
                comps.minute = store.reminderMinute
                reminderDate = Calendar.current.date(from: comps) ?? Date()
            }
        }
    }
}
