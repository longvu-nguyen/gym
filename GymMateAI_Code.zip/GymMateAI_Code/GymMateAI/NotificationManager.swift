import Foundation
import UserNotifications

final class NotificationManager {
    static let shared = NotificationManager()
    private init() {}

    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error {
                print("Notification permission error:", error.localizedDescription)
            }
            print("Notification permission granted:", granted)
        }
    }

    func scheduleDailyWorkoutReminder(hour: Int, minute: Int) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["dailyWorkoutReminder"])

        let content = UNMutableNotificationContent()
        content.title = "Đến giờ tập rồi!"
        content.body = "Mở GymMate AI để xem hôm nay tập gì và bắt đầu buổi tập."
        content.sound = .default

        var dateComponents = DateComponents()
        dateComponents.hour = hour
        dateComponents.minute = minute

        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(
            identifier: "dailyWorkoutReminder",
            content: content,
            trigger: trigger
        )

        center.add(request) { error in
            if let error {
                print("Schedule reminder error:", error.localizedDescription)
            }
        }
    }
}
