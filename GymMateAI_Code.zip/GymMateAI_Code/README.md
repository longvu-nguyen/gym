# GymMate AI - SwiftUI iPhone App

App gồm:
- Chọn tập phòng gym / ở nhà có tạ / ở nhà không dụng cụ
- App tự chia lịch tập theo ngày
- Video hướng dẫn động tác bằng VideoPlayer
- Đếm giờ nghỉ giữa hiệp
- Lưu lịch sử hôm nay đã tập gì bằng UserDefaults
- Báo thức nhắc tập mỗi ngày bằng UserNotifications
- Camera hình que bằng AVFoundation + Vision
- Báo lỗi form cơ bản cho Squat, Push-up, Plank, Lunge

## Cách dùng trong Xcode

1. Mở Xcode.
2. File > New > Project > iOS > App.
3. Product Name: `GymMateAI`.
4. Interface: SwiftUI.
5. Language: Swift.
6. Minimum Deployments nên để iOS 16.0 hoặc cao hơn.
7. Xóa file `ContentView.swift` cũ hoặc thay nội dung bằng file trong thư mục này.
8. Kéo toàn bộ file `.swift` trong thư mục `GymMateAI` vào project.
9. Chọn `Copy items if needed`.
10. Vào Info.plist thêm quyền camera:

Key:
`Privacy - Camera Usage Description`

Value:
`GymMate AI cần camera để vẽ hình que và kiểm tra tư thế tập.`

11. Cắm iPhone thật, chọn Team ký app, rồi bấm Run.

## Video hướng dẫn

App vẫn chạy nếu chưa có video. Nếu muốn thêm video thật:
- Kéo file mp4 vào Xcode.
- Tên video nên đặt như sau:
  - squat.mp4
  - pushup.mp4
  - plank.mp4
  - lunge.mp4
  - crunch.mp4
  - jumpingjack.mp4
  - curl.mp4
  - shoulderpress.mp4
  - dumbbellrow.mp4
  - benchpress.mp4
  - latpulldown.mp4
  - cablerow.mp4
  - legpress.mp4

## Lưu ý camera hình que

- Phải chạy trên iPhone thật.
- Simulator thường không dùng được camera như mong muốn.
- Đặt iPhone xa đủ để thấy toàn thân.
- Ánh sáng rõ.
- Nếu skeleton bị lệch, mở file `PoseCameraView.swift`, tìm dòng:

`orientation: .leftMirrored`

Thử đổi thành:

`orientation: .right`

hoặc đổi camera từ `.front` sang `.back`.
